const Home = {

    template: `
        <div>
            <h1>Home</h1>

            <p>
                Selamat datang di aplikasi VueJS + REST API
                CodeIgniter 4.
            </p>
        </div>
    `
}