const Login = {

    template: `
    <div class="login-container">

        <div class="login-box">

            <h2>Login User</h2>

            <form @submit.prevent="doLogin">

                <div class="form-group">
                    <label>Username</label>
                    <input type="text"
                           v-model="username"
                           required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password"
                           v-model="password"
                           required>
                </div>

                <button type="submit"
                        class="btn-login">
                    Login
                </button>

                <p class="error-msg"
                   v-if="errorMessage">
                    {{ errorMessage }}
                </p>

            </form>

        </div>

    </div>
    `,

    data() {
        return {
            username: '',
            password: '',
            errorMessage: ''
        }
    },

    methods: {

        doLogin() {

            axios.post(
                apiUrl + '/user/login',
                {
                    username: this.username,
                    password: this.password
                }
            )

            .then(response => {

                localStorage.setItem(
                    'token',
                    'login-success'
                );

                window.dispatchEvent(
                    new Event('storage')
                );

                router.push('/artikel');

            })

            .catch(error => {

                this.errorMessage =
                    'Username atau Password salah';

            });

        }

    }

}