const Artikel = {

    template: `
    <div>

        <h1>Daftar Artikel</h1>

        <button id="btn-tambah" @click="tambah">
            Tambah Data
        </button>

        <div class="modal" v-if="showForm">

            <div class="modal-content">

                <span class="close"
                    @click="showForm = false">
                    &times;
                </span>

                <form @submit.prevent="saveData">

                    <h3>{{ formTitle }}</h3>

                    <div>
                        <input type="text"
                            v-model="formData.judul"
                            placeholder="Judul"
                            required>
                    </div>

                    <div>
                        <textarea rows="8"
                            v-model="formData.isi">
                        </textarea>
                    </div>

                    <div>
                        <select v-model="formData.status">

                            <option
                                v-for="option in statusOptions"
                                :value="option.value">

                                {{ option.text }}

                            </option>

                        </select>
                    </div>

                    <button type="submit">
                        Simpan
                    </button>

                    <button type="button"
                        @click="showForm = false">
                        Batal
                    </button>

                </form>

            </div>

        </div>

        <table>

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>

                <tr v-for="(row,index) in artikel">

                    <td>{{ row.id }}</td>
                    <td>{{ row.judul }}</td>
                    <td>{{ statusText(row.status) }}</td>

                    <td>

                        <button @click="edit(row)">
                            Edit
                        </button>

                        <button @click="hapus(index,row.id)">
                            Hapus
                        </button>

                    </td>

                </tr>

            </tbody>

        </table>

    </div>
    `,

    data() {

        return {

            artikel: [],

            formData: {
                id: null,
                judul: '',
                isi: '',
                status: 0
            },

            showForm: false,

            formTitle: 'Tambah Data',

            statusOptions: [
                {
                    text: 'Draft',
                    value: 0
                },
                {
                    text: 'Publish',
                    value: 1
                }
            ]

        }
    },

    mounted() {
        this.loadData()
    },

    methods: {

        loadData() {

            axios.get(apiUrl + '/post')

            .then(response => {
                this.artikel = response.data.artikel
            })

            .catch(error => {
                console.log(error)
            })

        },

        statusText(status) {

            return status == 1
                ? 'Publish'
                : 'Draft'
        },

        tambah() {

            this.showForm = true

            this.formTitle = 'Tambah Data'

            this.formData = {
                id: null,
                judul: '',
                isi: '',
                status: 0
            }

        },

        edit(data) {

            this.showForm = true

            this.formTitle = 'Ubah Data'

            this.formData = {
                id: data.id,
                judul: data.judul,
                isi: data.isi,
                status: data.status
            }

        },

        saveData() {

            const config = {
                headers: {
                    Authorization:
                        'Bearer ' +
                        localStorage.getItem('token')
                }
            };

            if(this.formData.id !== null)
            {
                axios.put(
                    apiUrl + '/post/' + this.formData.id,
                    this.formData,
                    config
                )
                .then(response => {

                    this.loadData();
                    this.showForm = false;

                })
                .catch(error => {

                    console.log(error);

                });

            }
            else
            {
                axios.post(
                    apiUrl + '/post',
                    this.formData,
                    config
                )
                .then(response => {

                    this.loadData();
                    this.showForm = false;

                })
                .catch(error => {

                    console.log(error);

                });
            }

        },

        hapus(index,id) {

            if(confirm('Yakin hapus data?'))
            {
                axios.delete(
                    apiUrl + '/post/' + id,
                    {
                        headers: {
                            Authorization:
                                'Bearer ' +
                                localStorage.getItem('token')
                        }
                    }
                )
                .then(response => {

                    this.artikel.splice(index,1)

                })
                .catch(error => {

                    console.log(error)

                });
            }

        }
    }

}