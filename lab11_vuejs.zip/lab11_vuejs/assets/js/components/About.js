const About = {

    template: `
    <div class="profile-card">

        <div class="profile-info">
            <h2>Profil Mahasiswa</h2>

            <p><strong>Nama :</strong> Askaria Davan Dafyanza</p>
            <p><strong>NIM :</strong> 312410298</p>
            <p><strong>Kelas :</strong> I241B</p>
            <p><strong>Program Studi :</strong> Teknik Informatika</p>

            <p>
                Mahasiswa Universitas Pelita Bangsa yang sedang
                mempelajari VueJS, REST API, dan CodeIgniter 4.
            </p>
        </div>

        <div class="profile-photo-container">
            <img
                src="assets/img/Davan.jpg"
                alt="Foto Profil"
                class="profile-photo">
        </div>

    </div>
    `
}