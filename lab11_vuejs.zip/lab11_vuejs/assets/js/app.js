const apiUrl = 'http://127.0.0.1/lab11_ci/ci4/public'

const routes = [

    {
        path: '/',
        component: Home
    },

    {
        path: '/artikel',
        component: Artikel,
        meta: {
            requiresAuth: true
        }
    },

    {
        path: '/about',
        component: About,
        meta: {
            requiresAuth: true
        }
    },

    {
        path: '/login',
        component: Login
    }

]

const router = VueRouter.createRouter({

    history: VueRouter.createWebHashHistory(),
    routes

})

router.beforeEach((to, from, next) => {

    const isLoggedIn =
        localStorage.getItem('token');

    if (
        to.meta.requiresAuth &&
        !isLoggedIn
    ) {

        alert('Login terlebih dahulu');

        next('/login');

    } else {

        next();

    }

});

const app = Vue.createApp({

    data() {
        return {
            isLoggedIn: localStorage.getItem('token')
                ? true
                : false
        }
    },

    methods: {

        logout() {

            localStorage.removeItem('token');

            this.isLoggedIn = false;

            router.push('/login');

        }

    },

    mounted() {

        window.addEventListener('storage', () => {

            this.isLoggedIn =
                localStorage.getItem('token')
                ? true
                : false;

        });

    }

})

app.use(router)

app.mount('#app')